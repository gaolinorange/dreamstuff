#ifndef SUBPANEL_H
#define SUBPANEL_H

#include <QWidget>
#include <QHBoxLayout>
#include "PanelItem.h"

class GSubPanel : public QWidget
{
public:
	GSubPanel(QWidget * parent)
		: QWidget(parent)
	{
		numItems = 3;
		items = new GPanelItem [numItems];

		layout = new QHBoxLayout();
		for(int i = 0; i < numItems; i++)
			layout->addWidget(&items[i]);
		setLayout(layout);
	}
	~GSubPanel()
	{
		delete items;		
		delete layout;
	}
public:
	void setIndexValue(int idx,const QString& value);
	GPanelItem * getItem(int idx);
	int getNumItems()  { return numItems; }
private:
	int numItems;
	GPanelItem * items;
	QHBoxLayout * layout;
};

#endif
