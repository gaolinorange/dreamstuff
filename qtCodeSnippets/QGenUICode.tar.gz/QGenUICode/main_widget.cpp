#include "main_widget.h"
#include <QGridLayout>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QDialog>
#include <QMessageBox>
#include <QtDebug>
#include <QScrollArea>
#include <QApplication>
#include "DialogCodePreview.h"
#include "qlogger.h"

void MainWidget::createMenu()
{
	menuBar = new QMenuBar;
	fileMenu = new QMenu(QString("&File"),this);
	newAction = new QAction(QString(tr("&New")),this);
	fileMenu->addAction(newAction);
	QObject::connect(newAction,SIGNAL(triggered()),this,SLOT(fileNew()));

	saveXMLAction = new QAction(QString(tr("&Save As XML")),this);
	fileMenu->addAction(saveXMLAction);
	QObject::connect(saveXMLAction,SIGNAL(triggered()),this,SLOT(fileSaveAsXML()));

	genCodeAction = new QAction(QString(tr("&Gen Code")),this);
	fileMenu->addAction(genCodeAction);
	QObject::connect(genCodeAction,SIGNAL(triggered()),this,SLOT(fileGenCode()));

	closeAction = new QAction(QString(tr("&Close")),this);
	fileMenu->addAction(closeAction);
	QObject::connect(closeAction,SIGNAL(triggered()),this,SLOT(fileClose()));

	exitAction = new QAction(QString(tr("E&xit")),fileMenu);
	fileMenu->addAction(exitAction);
	QObject::connect(exitAction,SIGNAL(triggered()),qApp,SLOT(quit()));
	menuBar->addMenu(fileMenu);

	viewMenu = new QMenu(QString(tr("&View")));
	previewCodeAction = new QAction(QString(tr("Preview Code")),viewMenu);
	viewMenu->addAction(previewCodeAction);
	QObject::connect(previewCodeAction,SIGNAL(triggered()),this,SLOT(viewPreviewCode()));
	showGridAction = new QAction(QString(tr("Show Grid")),viewMenu);
	viewMenu->addAction(showGridAction);
	QObject::connect(showGridAction,SIGNAL(triggered()),this,SLOT(viewToggleShowGrid()));
	menuBar->addMenu(viewMenu);

	helpMenu = new QMenu(QString(tr("&Help")));
	aboutAction = new QAction(QString(tr("&About")),helpMenu);
	helpMenu->addAction(aboutAction);
	QObject::connect(aboutAction,SIGNAL(triggered()),this,SLOT(helpAbout()));
	menuBar->addMenu(helpMenu);

	mainLayout.setMenuBar(menuBar);
}

void MainWidget::createUI()
{
	propertyWidget = new PropertyWidget(QString(tr("Properties")),this);
	widgetContainer = new WidgetContainer(QString(tr("Widgets")),this);
	listViewWidget = new ListViewWidget(QString(tr("ListView Widgets")),this);
	workspaceWidget = new UIDraftWorkspace(this);
	QLogger::logger = new QLogger(this);

	mainLayout.addWidget(widgetContainer,0,0,5,1);
	mainLayout.addWidget(workspaceWidget,0,1,5,4);
	mainLayout.addWidget(propertyWidget,0,5,3,1);
	mainLayout.addWidget(listViewWidget,3,5,1,1);
	mainLayout.addWidget(QLogger::logger,4,5,1,1);

	//set up the signal-slot s
	QObject::connect(&(widgetContainer->buttonGroup),SIGNAL(buttonClicked(QAbstractButton*)),
		this,SLOT(buttonGroupSelectChanged(QAbstractButton*)));

	setLayout(&mainLayout);
}


//SLots
void MainWidget::buttonGroupSelectChanged(QAbstractButton* button)
{
	qDebug()<<"entering MainWidget::buttonGroupSelectChanged";
	QList<QAbstractButton*> buttons = widgetContainer->buttonGroup.buttons();
	QAbstractButton* selectedBtn;
	foreach(selectedBtn,buttons){
		if(selectedBtn == button)
		{
			qDebug()<<"selectBtn's label: "<<selectedBtn->text();
			//change the name to indicate the user
			QString nameType = selectedBtn->text();
			propertyWidget->nameType_->setText(nameType);
			if(nameType == QString(tr("Label"))){
				qDebug()<<"typeName Label match.";
			
			}
			else if(nameType == QString(tr("Button"))){
				qDebug()<<"typename button match";
			}
			else{
			
			}
		}
	} 

}

void MainWidget::helpAbout()
{
	qDebug()<<"enter MainWidget::helpAbout slot";
	QMessageBox::information(this,QString("About"),QString(tr(" Gui designer for D3DGUI\n contact: dimetek.net jingwenlai@163.com\n")));
}

void MainWidget::fileNew()
{
	workspaceWidget->addForm();

	//setup signal-slots for UIForm
	propertyWidget->nameType_->setText(QString("Frame"));
	propertyWidget->editName_->setText(workspaceWidget->form()->name());
	QString str;
	QTextStream(&str)<<workspaceWidget->form()->pos().x()<<","<<workspaceWidget->form()->pos().y();
	propertyWidget->editPosition_->setText(str);
	propertyWidget->editPosition_->setReadOnly(true);
	str.clear();
	QTextStream(&str)<<workspaceWidget->form()->size().width()<<","<<workspaceWidget->form()->size().height();
	propertyWidget->editSize_->setText(str);

	//bidirectional signal-slots Connections
	QObject::connect(propertyWidget->editName_,SIGNAL(textChanged(const QString&)),
		workspaceWidget,SLOT(changeUIFormName(const QString&)));
	QObject::connect(propertyWidget->editSize_,SIGNAL(textChanged(const QString&)),
		workspaceWidget,SLOT(resizeUIForm(const QString&)));
	QObject::connect(propertyWidget->editPosition_,SIGNAL(textChanged(const QString&)),
		workspaceWidget,SLOT(moveUIForm(const QString&)));

	QObject::connect(workspaceWidget->form(),SIGNAL(activeWidgetChanged(const QString& ,const QWidget* )),
		propertyWidget,SLOT(changeWidgetProperties(const QString&,const QWidget* )));

}

void MainWidget::fileClose()
{
	if(workspaceWidget->form())
	{
		workspaceWidget->closeForm();
	}
}

void MainWidget::viewPreviewCode()
{
	DialogCodePreview codePreviewDialog;
	if(workspaceWidget->form())
	{
		codePreviewDialog.fillTabWidgetContent(workspaceWidget->form()->name());
	}
	codePreviewDialog.exec();
}

void MainWidget::viewToggleShowGrid()
{
	if(workspaceWidget && workspaceWidget->form())
	{
		workspaceWidget->form()->toggleShowGrid();
	}
}

void MainWidget::fileGenCode()
{
	if(workspaceWidget)
	{
		workspaceWidget->generateCode();
	}
}

void MainWidget::fileSaveAsXML()
{
	if(workspaceWidget)
	{
		workspaceWidget->saveAsXML();
	}
}


void MainWidget::setupConnections()
{
	/*
	QObject::connect(propertyWidget->editName_,SIGNAL(textChanged(const QString&)),
		workspaceWidget,SLOT(setFrameName(QString&))
		);
*/

/*
	QObject::connect(propertyWidget->editName_,SIGNAL(textChanged(const QString&)),
		workspaceWidget,SLOT(widgetNameChanged(const QString&)));
*/


}


