#ifndef UI_FORM_WIDGET_H
#define UI_FORM_WIDGET_H

#include <QFrame>
#include <QByteArray>
#include <QDataStream>
#include <QtGlobal>
#include <QWidget>
#include<QDragEnterEvent>
#include<QDragMoveEvent>
#include<QDropEvent>
#include <QtDebug>
#include <QGridLayout>
#include <QList>
#include <QtGui>
#include <QResizeEvent>
#include <QSpacerItem>
#include "ui_elements.h"
#include "qlogger.h"
//#include <QTextStream>


class UIFormWidget : public QFrame
{
	Q_OBJECT
public:
	UIFormWidget(QWidget* parent,Qt::WindowFlags f = 0)
		:QFrame(parent,f)
	{
		setAcceptDrops(true);
		gridLayout = new QGridLayout(this);
		setLayout(gridLayout);
		showGrid = true;
		showLayout = true;
		spanRow = 20,spanCol = 20;
		numRowLayoutCount = 4;
		numColLayoutCount = 8;

		name_ = QString("untitiled");
		uiWidgetLists.clear();
	}
	~UIFormWidget()
	{
		if(gridLayout){
			delete gridLayout;gridLayout = 0;
		}
		uiWidgetLists.clear();
	}
private:
	void dragEnterEvent(QDragEnterEvent* event)
	{
		if(event->mimeData()->hasFormat("text/plain")){
			qDebug()<<event->mimeData()->text();
			event->acceptProposedAction();
		}
		else if(event->mimeData()->hasFormat("application/ui_element_movement"))
		{
			event->acceptProposedAction();
		}
		else{
			event->ignore();
			qDebug()<<"dragEnterEvent : event ignore";
		}
	}
	void dragMoveEvent(QDragMoveEvent* event)
	{
		if(event->mimeData()->hasFormat("text/plain")
			&& event->answerRect().intersects(this->geometry())){
				qDebug()<<"event->pos()="<<event->pos();
				event->acceptProposedAction();
		}
		else if(event->mimeData()->hasFormat("application/ui_element_movement")){
			event->acceptProposedAction();
		}
		else{
			event->ignore();
		}
	}
	void dropEvent(QDropEvent* event)
	{
		qDebug()<<"ui_form: dropEvent:";
		qDebug()<<event->mimeData()->text();
		qDebug()<<event->mimeData()->formats();
		if(event->mimeData()->hasFormat("text/plain")){
			qDebug()<<"DropEvent: dropat pos: "<<event->pos();
			event->acceptProposedAction();

			//TODO: Refactory
			//Important: judge the widget type and insert a widget
			QString widgetType = event->mimeData()->text();
			if(widgetType == QString(tr("Label"))){
				static int labelNum = 0;
				QString numString; 
				numString.setNum(labelNum);
				QString labelName  =QString("label")+numString;
				UILabel * label = new UILabel(labelName,this);

				addFormWidget(UI_LABEL,label,event->pos(),dynamic_cast<UIElement*>(label)->size());
				labelNum++;
			}else if(widgetType == QString(tr("Button"))){
				static int buttonNum = 0;
				QString numString;
				numString.setNum(buttonNum);
				QString buttonName = QString(tr("Button"))+numString;

				UIPushButton* button = new UIPushButton(buttonName,this);
				dynamic_cast<UIElement*>(button)->resize(100,30);

				addFormWidget(UI_BUTTON,button,event->pos(),dynamic_cast<UIElement*>(button)->size());
				buttonNum++;
			}else if(widgetType == QString(tr("Menu"))){
			//TODO
			}
			else{
				QMessageBox::warning(0,QString(tr("Warning")),
					QString(tr("This type of widget is not implement in dropEvent yet")));
			}
		}
		else if(event->mimeData()->hasFormat("application/ui_element_movement" ))//TODO: �˴�����Ҫ�������е�UIElement���ƶ�
		{
			QByteArray itemData = event->mimeData()->data("application/ui_element_movement");
			QDataStream dataStream(&itemData,QIODevice::ReadOnly);
			int elementType;
			QPoint oldPos;
			dataStream>>elementType>>oldPos;
			qDebug()<<"elementType: "<<elementType<<" oldPos: "<<oldPos;
			//TODO: move the widget from old pos to new pos

		}
		else{
			event->ignore();
		}
	}

protected:
	void mousePressEvent(QMouseEvent* event)
	{
		QWidget* widget = childAt(event->pos());
		//qDebug()<<widget;
		QString strMessage;
		strMessage.sprintf("pos: %d,%d: ",event->pos().x(),event->pos().y());
		QLogger::getSingletonPtr()->appendMessage(strMessage);

		//TODO:  ������ѡwidget������UIElement�б����õ�������.
		setActiveWidget(QString("test"),widget);
	}
private:
	void setActiveWidget(const QString& title,QWidget* widget)
	{
		QLogger::getSingletonPtr()->appendMessage("ui_form_widget: setActiveWidget");

		activeUIWidget = widget;
		emit activeWidgetChanged(title,activeUIWidget);
	}
signals:
	void activeWidgetChanged(const QString& ,const QWidget* );

public:	
	void toggleShowGrid()
	{
		showGrid = !showGrid;
		update();
	}
	void toggleShowLayout()
	{
		showLayout = !showLayout;
	}
public: 
	QString& name(){ return name_; }
	void setName(const QString& name)
	{
		name_ = name;
	}
private:
	QString name_;

private:
	void translatePosSizeToGridNum(const QPoint pos,const QSize& size,
		int & rowBegin,int & colBegin, int& rowSpan,int & colSpan)
	{
		qDebug()<<"translatePosSizeToGridNum : @param: pos"<<pos<<" size: "<<size;

		rowSpan = 1;
		colSpan = 1;

		int layoutItemHeight = height()/numRowLayoutCount;
		int layoutItemWidth = width()/numColLayoutCount;

		rowBegin = int(pos.y()/layoutItemHeight);
		colBegin = int(pos.x()/layoutItemWidth);

		Q_ASSERT(colBegin < numColLayoutCount);		
	}
	void insertSpacerItem()
	{
		QSpacerItem * horizonalSpacerItem = new QSpacerItem(width(),height());
		QSpacerItem* verticalSpacerItem = new QSpacerItem(width(),height());
		gridLayout->addItem(horizonalSpacerItem,0,numColLayoutCount-1,1,numColLayoutCount);
		gridLayout->addItem(verticalSpacerItem,0,0,numRowLayoutCount,1);
	}
	void addFormWidget(UIElementType elementType,UIElement * element,const QPoint pos,QSize& size)
	{
		uiWidgetLists.push_back(element);

		QWidget* widget;
		switch(elementType)
		{
		case UI_BUTTON:
			widget = dynamic_cast<QPushButton*>(element);
			break;
		case UI_LABEL:
			widget = dynamic_cast<QLabel*>(element);
			break;
		case UI_MENU:
			break;
		default:
			break;
		}

	
		activeUIWidget = widget;

		QString strMessage;
//		QTextStream(&strMessage)<<"ui_form_widget: insertWidget: @params: pos: "<<pos<<" size: "<<size;
		strMessage = QString("Test message");
		QLogger::getSingletonPtr()->appendMessage(strMessage);

		qDebug()<<"ui_form_widget: insetWidget: @params: widget name: "
			<<" pos: "<<pos<<" size: "<<size;
		//translate the pos,and size to the layout insenstive means
		//TODO:���������Ĳ���ת����layout�ܹ���ʶ�Ĳ�����
		int rowBegin=0,colBegin=0,rowSpan=1,colSpan=1;
		translatePosSizeToGridNum(pos,size,rowBegin,colBegin,rowSpan,colSpan);

		qDebug()<<"grid layout index after translate: "
			<<"rowBegin= "<<rowBegin<<" colBegin= "<<colBegin
			<<"rowSpan = "<<rowSpan<<"colSpan= "<<colSpan;
		qDebug()<<"numRowLayoutCount = "<<numRowLayoutCount<<"numColLayoutCount = "<<numColLayoutCount;
		qDebug()<<gridLayout->rowCount()<<": "<<gridLayout->columnCount();
		qDebug()<<gridLayout->cellRect(0,1);

		gridLayout->addWidget(widget,rowBegin,colBegin,rowSpan,colSpan);

		setupWidgetConnection(elementType,widget);
	}

	void setupWidgetConnection(UIElementType elementType,QWidget* widget)
	{
		switch(elementType){
		case UI_LABEL:
			{
			}
			break;
		case UI_BUTTON:
			{
/*
				UIPushButton* pushButton = dynamic_cast<UIPushButton*>(widget);
				QObject::connect(gMainWidget->getPropertyWidget()->editName_,
					SIGNAL(textChanged(const QString&)),
					pushButton,changeName(const QString&));
*/

				/*
				QObject::connect(gMainWidget->getPropertyWidget()->editPosition_,
					SIGNAL(textChanged(const QString&)),
					pushButton,changePos(const QString&));
*/
			}
			break;
		case UI_MENU:
			{
			}
			break;
		default:
			break;
		}
	}

protected:	
	void paintEvent(QPaintEvent* event)
	{	
		if(showGrid)
		{
			//paint the grids
			QPainter painter(this);
			QPoint point;
			//painter.drawPoints(gridPoints,numCols*numRows);
			for(int colBegin = 0; colBegin < width(); colBegin+= spanCol){
				for(int rowBegin = 0; rowBegin < height(); rowBegin += spanRow){
					point.setX(colBegin);
					point.setY(rowBegin);
					painter.drawPoint(point);
				}
			}
		}
/*	  //Currently not show the layout,has some bugs
		if(showLayout){
			QPainter painter(this);
			painter.setPen(QColor(0,0,255));

			QPoint startPoint,endPoint;
			float layoutItemHeight = height()/numRowLayoutCount;
			float layoutItemWidth = width()/numColLayoutCount;

			for(int i = 0; i <= numRowLayoutCount; i++){
					startPoint = QPoint(0,i*layoutItemHeight);
					endPoint = QPoint(width(),i*layoutItemHeight);				
					painter.drawLine(startPoint,endPoint);
			}

			for(int j = 0; j <= numColLayoutCount; j++){
				startPoint = QPoint(j*layoutItemWidth,0);
				endPoint = QPoint(j*layoutItemWidth,height());
			    painter.drawLine(startPoint,endPoint);
			}
		}
*/
		QFrame::paintEvent(event);
	}
	void resizeEvent(QResizeEvent * event)
	{
		qDebug()<<"ui_form: resieEvent: numRowLayoutCount : "<<numRowLayoutCount<<" numColLayoutCount: "<<numColLayoutCount;

		QSpacerItem * dummyHorizontalItem = new QSpacerItem(width(),height());
		gridLayout->addItem(dummyHorizontalItem,0,0,-1,-1);
		QSpacerItem* dummyVerticalItem = new QSpacerItem(width(),height());
		gridLayout->addItem(dummyVerticalItem,0,0,-1,-1);
	}
public:
	QList<UIElement*> getUiWidgetList()
	{
		return uiWidgetLists;
	}
private:	
	QGridLayout * gridLayout;
	QList<UIElement*> uiWidgetLists;
	QWidget* activeUIWidget;
	bool showGrid;
	bool showLayout;
	/**
	The display grid, also,it helps to determine the insert widget's grid layout index
	*/
	qreal spanRow,spanCol;

	int numRowLayoutCount;
	int numColLayoutCount;
};

#endif
