#ifndef D3DUI_CODE_SNIPPET_H
#define D3DUI_CODE_SNIPPET_H

#include<QString>
#include <QMap>
#include <QVector>
#include <QtGui>
#include <QList>
#include "ui_form_widget.h"

enum BriefName
{
	UI_CODESNIPPET_HEADER_DECLAR_BEGIN = 0,
	UI_CODESNIPPET_HEADER_DECLAR_END,
	UI_CODESNIPPET_INCLUDE_HEADER,

	UI_CODESNIPPET_CLASS_HEADER,
	UI_CODESNIPPET_CLASS_CONSTRUCTOR,
	UI_CODESNIPPET_INITCONTROLS,
	UI_CODESNIPPET_RESETDEVICE,

	UI_CODESNIPPET_EVENTCALLBACK,

	UI_CODESNIPPET_CLASS_BLOCK_END,


	UI_CODESNIPPET_PUBLIC,
	UI_CODESNIPPET_PRIVATE,
	UI_CODESNIPPET_PROTECTED,

	UI_CODESNIPPET_NEWLINE,
	UI_CODESNIPPET_TAB,


	//CPP related
	UI_CPP_HEADER,
	UI_CPP_CONSTRUCTOR,
	UI_CPP_DESTRUCTOR,
	UI_CPP_INITCONTROLS,
	UI_CPP_GUIEVENT,
	UI_CPP_ONRESETDEVICE,



	UI_CODESNIPPET_MAX = 0x256,

	UI_CODESNIPPET_USER_DEFINED,


	UI_CODESNIPPET_TOTAL = 0x512
};



class D3DUICodeSnippet
{
public:
	D3DUICodeSnippet(const QString& classname)
	{
		className_ = classname;
		upperClassName_ = className_.toUpper();
		brief_snippet_map.clear();
		setupBriefSnippetMap();
		//		userAddControlIds.clear();
		flagSettingEnd = false;
		userDefinedID = UI_CODESNIPPET_USER_DEFINED;
	}
	~D3DUICodeSnippet()
	{
		brief_snippet_map.clear();
		//		userAddControlIds.clear();
	}
private:
	//todo
	void setupBriefSnippetMap()
	{
		//Header File Related Snippets
		brief_snippet_map[UI_CODESNIPPET_HEADER_DECLAR_BEGIN] = 
			QString("#ifndef ")+upperClassName_+QString("_H\n")
			+QString("#define ")+upperClassName_+QString("_H\n");

		brief_snippet_map[UI_CODESNIPPET_INCLUDE_HEADER] =
			QString("#include ")+QString("\"GUI.h\"\n");


		brief_snippet_map[UI_CODESNIPPET_EVENTCALLBACK] = 
			QString("void CALLBACK On")
			+className_
			+QString("Event(UINT nEvent,int nControlID,CGuiControl* pControl,void * pUserContext);\n");

		brief_snippet_map[UI_CODESNIPPET_CLASS_HEADER]=
			QString("class ")
			+className_
			+QString(" : public CGuiManager \n{\n");

		brief_snippet_map[UI_CODESNIPPET_CLASS_CONSTRUCTOR]=
			QString("public:\n\t")+
			className_+QString("(LPDIRECT3DDEVICE9 device,HWND hwnd);\n")
			+QString("\t ~")+className_+QString("() \n");

		brief_snippet_map[UI_CODESNIPPET_INITCONTROLS]=
			QString("void InitControls(int width,int height);\n");
		brief_snippet_map[UI_CODESNIPPET_RESETDEVICE] =
			QString("HRESULT OnResetDevice(IDirect3DDevice9* pd3dDevice,\n")+
			QString("\t\t const D3DSURFACE_DESC* pBackBufferSurfaceDesc,void* pUserContext);\n");

		brief_snippet_map[UI_CODESNIPPET_CLASS_BLOCK_END]=
			QString("};\n");

		brief_snippet_map[UI_CODESNIPPET_HEADER_DECLAR_END]=
			QString("#endif\n");

		brief_snippet_map[UI_CODESNIPPET_NEWLINE] = QString("\n");
		brief_snippet_map[UI_CODESNIPPET_TAB] = QString("\t");
		brief_snippet_map[UI_CODESNIPPET_PUBLIC] =  QString("public:\n");
		//Source File related Snippets

		brief_snippet_map[UI_CPP_HEADER] = 
			QString("#include \"")+className_+QString(".hpp\"");
		brief_snippet_map[UI_CPP_CONSTRUCTOR] = 
			className_+QString("::")+className_+QString("(LPDIRECT3DDEVICE9 device,HWND hwnd)\n")
			+QString(": CGuiManager(device,hwnd)\n")
			+QString("{\n")
			+QString("\t m_pDialog->SetCallBack(On")+className_+QString("Event);\n")
			+QString("}\n");
		brief_snippet_map[UI_CPP_DESTRUCTOR] = 
			className_+QString("::~")+className_+QString("()\n")
			+QString("{\n")
			+QString("}\n");
		brief_snippet_map[UI_CPP_INITCONTROLS] = 
			QString("void ")+className_+QString("::")
			+QString("InitControls(int width,int height)\n")
			+QString("{\n")
			+QString("//TODO: add your initialization code here\n")
			+QString("}\n");

		brief_snippet_map[UI_CPP_ONRESETDEVICE] = 
			QString("HRESULT ")+className_+QString("::OnResetDevice(IDirect3DDevice9* pd3dDevice,\n")
			+QString("\t const D3DSURFACE_DESC* pBackBufferSurfaceDesc,void *pUserContext)\n")
			+QString("{\n")
			+QString("//TODO: add you reset codes here\n")
			+QString(" return D3D_OK;\n")
			+QString("}\n");


		//CPP_GUI_EVENT
		int n = brief_snippet_map[UI_CODESNIPPET_EVENTCALLBACK].indexOf(QChar(';'));

		brief_snippet_map[UI_CPP_GUIEVENT] = 
			brief_snippet_map[UI_CODESNIPPET_EVENTCALLBACK].left(n)
		+QString("\n{\n")
			+QString("// TODO: add event callback code here")
			+QString("}\n");
	}

public:
	//TODO:  �ⲿ��Ӧ�ø���UI�����Զ�����
	void beginAddControl()
	{
		flagSettingEnd = false;
	}
	void addControl(QString & id,QString & type,QPoint & pos,QSize & size)
	{

	}
	void endAddControl()
	{
		flagSettingEnd = true;
	}

	void genCode(UIFormWidget* uiform,const QSize& formSize)
	{
		QString widthString,heightString;
		widthString.setNum(formSize.width());
		heightString.setNum(formSize.height());

		brief_snippet_map[UI_CODESNIPPET_INITCONTROLS]=
			QString("void InitControls(int width = ") + widthString + QString(", int height = ")+heightString+QString(");\n");

		genHeaderFile(className_+QString(".hpp"));
		genCppFile(className_+QString(".cpp"));

		QLogger::getSingletonPtr()->appendMessage(QString("class  : ")+className_+QString("    : file generated"));
	}
private:
	void genHeaderFile(const QString & filename)
	{
		generatedCode_.clear();
		setupHeaderBegin();
		insertNewLine(2);

		setupControls();
		insertNewLine(1);

		setupGUIEvent();
		insertNewLine(2);

		setupClass();
		insertNewLine(3);

		setupHeaderEnd();

		QFile headerFile(filename);
		if(!headerFile.open(QIODevice::WriteOnly | QIODevice::Text))
			return;

		QTextStream textStream(&headerFile);
		textStream<<generatedCode_;
		headerFile.close();
	}
	void genCppFile(const QString& filename)
	{
		generatedCode_.clear();
		setupCppHeader();
		insertNewLine(2);
		setupGUIEvent();

		insertNewLine(2);
		setupCppConstructor();

		insertNewLine(1);
		setupCppDestructor();

		insertNewLine(2);
		setupCppInitControls();

		insertNewLine(2);

		setupCppGuiEvent();

		insertNewLine(2);
		setupCppOnResetDevice();

		QFile cppFile(filename);
		if(!cppFile.open(QIODevice::WriteOnly | QIODevice::Text))
			return;

		QTextStream textStream(&cppFile);
		textStream<<generatedCode_;
		cppFile.close();
	}

private://for cpp file
	//flexible method
	void setupCppGuiEvent()
	{
		generatedCode_ +=
			brief_snippet_map[UI_CPP_GUIEVENT];
	}
	void setupCppOnResetDevice()
	{
		generatedCode_ +=
			brief_snippet_map[UI_CPP_ONRESETDEVICE];
	}
	void setupCppHeader()
	{
		generatedCode_ +=
			brief_snippet_map[UI_CPP_HEADER];
	}
	void setupCppConstructor()
	{
		generatedCode_ +=
			brief_snippet_map[UI_CPP_CONSTRUCTOR];
	}
	void setupCppDestructor()
	{
		generatedCode_ +=
			brief_snippet_map[UI_CPP_DESTRUCTOR];
	}
	void setupCppInitControls()
	{
		generatedCode_ +=
			brief_snippet_map[UI_CPP_INITCONTROLS];
	}

private://For Header
	void setupHeaderBegin()
	{
		generatedCode_ += 
			brief_snippet_map[UI_CODESNIPPET_HEADER_DECLAR_BEGIN];
		insertNewLine(2);
		generatedCode_ += 
			brief_snippet_map[UI_CODESNIPPET_INCLUDE_HEADER];
	}
	//TODO
	void setupControls()
	{
		if(flagSettingEnd == false)
		{
			QLogger::getSingletonPtr()->appendMessage(QString(QObject::tr("Warning: Do not want to add controls? ")));
		}
/*	
		beginAddControl();
		UIElement* pElement;
		foreach(pElement,form->getUiWidgetList()){
			//here, you should think about the header for IDC_ RESOURCES and cpp file for Adding Type of Controls
			//TODO
		}
		endAddControl();
*/
	}
	void insertNewLine(int num = 1)
	{
		for(int i = 0; i < num; i++){
			generatedCode_ +=
				brief_snippet_map[UI_CODESNIPPET_NEWLINE];
		}		
	}
	void insertTab()
	{
		generatedCode_ += brief_snippet_map[UI_CODESNIPPET_TAB];
	}
	void insertPublicString()
	{
		generatedCode_ += brief_snippet_map[UI_CODESNIPPET_PUBLIC];
	}
	void setupGUIEvent()
	{
		generatedCode_ += 
			brief_snippet_map[UI_CODESNIPPET_EVENTCALLBACK];
	}
	void setupClass(){
		//class declaration
		generatedCode_ +=
			brief_snippet_map[UI_CODESNIPPET_CLASS_HEADER];
		//class constructor& destructor
		generatedCode_ +=
			brief_snippet_map[UI_CODESNIPPET_CLASS_CONSTRUCTOR];

		insertPublicString();
		insertTab();
		generatedCode_ += 
			brief_snippet_map[UI_CODESNIPPET_INITCONTROLS];
		insertTab();
		generatedCode_ +=
			brief_snippet_map[UI_CODESNIPPET_RESETDEVICE];

		generatedCode_ += 
			brief_snippet_map[UI_CODESNIPPET_CLASS_BLOCK_END];
	}
	void setupHeaderEnd(){
		generatedCode_ +=
			brief_snippet_map[UI_CODESNIPPET_HEADER_DECLAR_END];
	}

private:
	bool flagSettingEnd;
	QString generatedCode_;

	int userDefinedID;
	QMap<int,QString> brief_snippet_map;

	UIFormWidget* form;
	QString className_;
	QString upperClassName_;

};


#endif