/********************************************************************************
** Form generated from reading ui file 'CodePreview.ui'
**
** Created: Sat Nov 28 11:01:11 2009
**      by: Qt User Interface Compiler version 4.5.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_DIALOGCODEPREVIEW_H
#define UI_DIALOGCODEPREVIEW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QHeaderView>
#include <QtGui/QScrollArea>
#include <QtGui/QTabWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogCodePreview
{
public:
    QDialogButtonBox *buttonBox;
    QTabWidget *tabWidget;
    QWidget *tabHeader;
    QScrollArea *headerScrollArea;
    QWidget *scrollAreaWidgetContents;
    QTextEdit *textEditHeader;
    QWidget *tabSource;
    QScrollArea *sourceScrollArea;
    QWidget *scrollAreaWidgetContents_2;
    QTextEdit *textEditSource;

    void setupUi(QDialog *DialogCodePreview)
    {
        if (DialogCodePreview->objectName().isEmpty())
            DialogCodePreview->setObjectName(QString::fromUtf8("DialogCodePreview"));
        DialogCodePreview->resize(670, 684);
        buttonBox = new QDialogButtonBox(DialogCodePreview);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(320, 650, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        tabWidget = new QTabWidget(DialogCodePreview);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(20, 10, 631, 631));
        tabHeader = new QWidget();
        tabHeader->setObjectName(QString::fromUtf8("tabHeader"));
        tabHeader->setMaximumSize(QSize(16777213, 16777215));
        headerScrollArea = new QScrollArea(tabHeader);
        headerScrollArea->setObjectName(QString::fromUtf8("headerScrollArea"));
        headerScrollArea->setGeometry(QRect(-1, -1, 631, 611));
        headerScrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 629, 609));
        textEditHeader = new QTextEdit(scrollAreaWidgetContents);
        textEditHeader->setObjectName(QString::fromUtf8("textEditHeader"));
        textEditHeader->setGeometry(QRect(0, 0, 631, 611));
        headerScrollArea->setWidget(scrollAreaWidgetContents);
        tabWidget->addTab(tabHeader, QString());
        tabSource = new QWidget();
        tabSource->setObjectName(QString::fromUtf8("tabSource"));
        sourceScrollArea = new QScrollArea(tabSource);
        sourceScrollArea->setObjectName(QString::fromUtf8("sourceScrollArea"));
        sourceScrollArea->setGeometry(QRect(0, 0, 631, 611));
        sourceScrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 629, 609));
        textEditSource = new QTextEdit(scrollAreaWidgetContents_2);
        textEditSource->setObjectName(QString::fromUtf8("textEditSource"));
        textEditSource->setGeometry(QRect(0, 0, 631, 611));
        sourceScrollArea->setWidget(scrollAreaWidgetContents_2);
        tabWidget->addTab(tabSource, QString());

        retranslateUi(DialogCodePreview);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogCodePreview, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogCodePreview, SLOT(reject()));

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(DialogCodePreview);
    } // setupUi

    void retranslateUi(QDialog *DialogCodePreview)
    {
        DialogCodePreview->setWindowTitle(QApplication::translate("DialogCodePreview", "\344\273\243\347\240\201\351\242\204\350\247\210", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tabHeader), QApplication::translate("DialogCodePreview", "Header", 0, QApplication::UnicodeUTF8));
        tabWidget->setTabText(tabWidget->indexOf(tabSource), QApplication::translate("DialogCodePreview", "Source", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(DialogCodePreview);
    } // retranslateUi

};

namespace Ui {
    class DialogCodePreview: public Ui_DialogCodePreview {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCODEPREVIEW_H
