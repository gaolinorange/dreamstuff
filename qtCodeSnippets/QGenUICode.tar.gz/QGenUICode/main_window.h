#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "main_widget.h"
class QLogger;
class QMenuBar;
class QMenu;
class QAction;


class MainWindow : public QMainWindow
{
public:
	MainWindow()
	{
		setupMenu();
		setupCentralWidget();

		logger = 0;
	}
	~MainWindow()
	{
		if(logger)
		{
			delete logger; logger = 0;
		}
	}
private:
	void setupMenu();
	void setupCentralWidget();
private slots:
	void helpAbout();
	void fileNew();
	void fileSaveAsXML();
	void fileGenCode();
	void viewPreviewCode();
	void viewToggleShowGrid();
private:
	MainWidget * mainWidget;
	 QLogger * logger;
private://menu related
	QMenuBar * menuBar;
	QMenu * fileMenu;
	QAction * newAction;
	QAction * saveXMLAction;
	QAction * genCodeAction;

	QMenu* viewMenu;
	QAction* previewCodeAction;
	QAction* showGridAction;

	QAction * exitAction;
	QMenu * helpMenu;
	QAction * aboutAction;
};

#endif