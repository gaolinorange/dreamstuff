#ifndef PROPERTY_WIDGET_H
#define PROPERTY_WIDGET_H

#include <QGroupBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QString>
#include <QTextStream>
#include <QLabel>
#include <QLineEdit>
#include <QtDebug>
#include "qlogger.h"


class PropertyWidget : public QGroupBox
{
  Q_OBJECT
public:
  PropertyWidget(const QString & title,QWidget * parent = 0)
    : QGroupBox(title,parent)
  {
    QHBoxLayout * hbox = new QHBoxLayout();
    QVBoxLayout * vbox = new QVBoxLayout();
    //set up layout
    labelType_ = new QLabel(QString(QObject::tr("Type")));
	labelType_->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    nameType_  = new QLabel(QString(QObject::tr("")));//read only
	nameType_->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    hbox->addWidget(labelType_);
    hbox->addWidget(nameType_);
    vbox->addLayout(hbox);


    //the widget's propertites
	QHBoxLayout* hbox2 = new QHBoxLayout();
    labelName_ = new QLabel(QString(QObject::tr("Name")));
	labelName_->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    editName_ = new QLineEdit(this);
	editName_->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    hbox2->addWidget(labelName_);
    hbox2->addWidget(editName_);
	vbox->addLayout(hbox2);
	
	QHBoxLayout* hbox3 = new QHBoxLayout;
    labelPosition_ = new QLabel(QString(QObject::tr("Position")));
	labelPosition_->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    editPosition_ = new QLineEdit(this);
	editPosition_->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    hbox3->addWidget(labelPosition_);
    hbox3->addWidget(editPosition_);
    vbox->addLayout(hbox3);

	QHBoxLayout* hbox4 = new QHBoxLayout;
    labelSize_ = new QLabel(QString(QObject::tr("Size")));
	labelSize_->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    editSize_ = new QLineEdit(this);
	editSize_->setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    hbox4->addWidget(labelSize_);
    hbox4->addWidget(editSize_);
    vbox->addLayout(hbox4);

	vbox->addStretch();

    setLayout(vbox);
	setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
  }
  ~PropertyWidget()
  {
    delete labelType_; delete nameType_;
    delete labelName_; delete editName_;
    delete labelPosition_; delete editPosition_;
    delete labelSize_; delete editSize_;
  }
public slots:
  void changeTypeName(const QString& name)
  {
    nameType_->setText(name);
  }  
  void changeTypePosition(const QPoint& pos)
  {
	  QString strPos;
	  strPos = strPos.sprintf("%d,%d",pos.x(),pos.y());
	  editPosition_->setText(strPos);
  }
  void changeTypeSize(const QSize& size)
  {
	  QString strSize;
	  strSize = strSize.sprintf("%d,%d",size.width(),size.height());
	  editSize_->setText(strSize);
  }
  void changeWidgetProperties(const QString& widgetName,const QWidget* widget)
  {
	  QLogger::getSingletonPtr()->appendMessage(QString("changedWidgetProperties"));
/*	
	  editName_->setText( widgetName);
	  QString messageString;
	  QTextStream(&messageString)<<widget->pos().x()<<","<<widget->pos().y();
	  editPosition_->setText(messageString);
	  messageString.clear();
	  QTextStream(&messageString)<<widget->size().width()<<","<<widget->size().height();
	  editSize_->setText(messageString);
	  */
  }
public:
  QLabel * labelType_;
  QLabel * nameType_;
  
  QLabel * labelName_;
  QLineEdit * editName_;
  QLabel * labelPosition_;
  QLineEdit * editPosition_;
  QLabel * labelSize_;
  QLineEdit * editSize_;  
};

#endif
