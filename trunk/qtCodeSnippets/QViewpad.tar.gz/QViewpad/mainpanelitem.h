#ifndef MAINPANELITEM_H
#define MAINPANELITEM_H

#include <QPushButton>

class MainPanelItem : public QPushButton
{
  Q_OBJECT
 public:
  MainPanelItem(QWidget* parent = 0)
    : QPushButton(parent)
    {
    }
  ~MainPanelItem()
    {
    }
 public:

 public slots:
    void updateText(const QString & str)
    {
      setText(str);
    }
};
  
#endif
