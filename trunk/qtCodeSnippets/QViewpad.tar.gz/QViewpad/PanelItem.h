#ifndef PANELITEM_H
#define PANELITEM_H

#include <QWidget>
#include <QHBoxLayout>
#include <QPushButton>
//#include <QLabel>
#include <QLineEdit>
#include <QObject>
#include <QFont>


class GPanelItem : public QWidget
{
	Q_OBJECT
public:
	GPanelItem(QWidget * parent = 0) : QWidget(parent)
	{
		increaseButton = new QPushButton(QString(tr("<")),this);
		QObject::connect(increaseButton,SIGNAL(clicked()),this,SLOT(increaseNum()));
		decreaseButton = new QPushButton(QString(tr(">")),this);
		QObject::connect(decreaseButton,SIGNAL(clicked()),this,SLOT(decreaseNum()));
		value = 0;

		QFont serifFont;
		serifFont.setFamily(QString("Times"));
		serifFont.setPointSize(20);
		serifFont.setStretch(QFont::UltraExpanded);
		serifFont.setBold(true);

		QString str;
		numEdit = new QLineEdit();
		numEdit->setAlignment(Qt::AlignCenter | Qt::AlignHCenter);
		numEdit->setFont(serifFont);
		numEdit->setText(str.setNum(value));
		numEdit->resize(numEdit->minimumSizeHint());

		layout = new QVBoxLayout();
		layout->addWidget(increaseButton);
		layout->addWidget(numEdit);
		layout->addWidget(decreaseButton);

		setLayout(layout);
	}
	~GPanelItem()
	{
		delete increaseButton;
		delete decreaseButton;
//		delete numLabel;
		delete numEdit;
	}


public:
	void reset()
	{
		setValue(0);
	}
	void setValue(int value)
	{
		this->value = value;
		QString str; 
		str.setNum(value);
		numEdit->setText(str);
	}
private slots:
	void increaseNum()
	{ 
		if(value < 9)
			value++;
		QString str;
		str.setNum(value);
		numEdit->setText(str);
	}
	void decreaseNum()
	{
		if(value > 0)
			value--;
		QString str;
		str.setNum(value);
		numEdit->setText(str);
	}
public:
	QPushButton * getIncreaseButton() { return increaseButton; }
	QPushButton * getDecreaseButton() { return decreaseButton; }
	QLineEdit * getNumEdit() { return numEdit;}
private:
	QPushButton* increaseButton;
	QPushButton* decreaseButton;
	QLineEdit * numEdit;
	QVBoxLayout * layout;
private:
	int value;
};


#endif
