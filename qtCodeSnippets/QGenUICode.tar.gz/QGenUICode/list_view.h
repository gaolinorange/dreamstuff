#ifndef LIST_VIEW_WIDGET_H
#define LIST_VIEW_WIDGET_H

#include <QGroupBox>
#include <QTreeWidget>
#include <QTreeView>

class ListViewWidget : public QGroupBox
{
  Q_OBJECT
  public:
  ListViewWidget(const QString & title,QWidget * parent = 0)
    : QGroupBox(title,parent)
  {
	  treeWidget = new QTreeWidget(this);
  }
  ~ListViewWidget()
  {
	  if(treeWidget)
		  delete treeWidget;
	  treeWidget = 0;
  }
public slots:


private:
	QTreeWidget * treeWidget;
};

#endif
