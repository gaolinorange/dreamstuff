#include "ui_draft_workspace.h"

#include <QtDebug>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QFrame>
#include <QMessageBox>



void UIDraftWorkspace::saveAsXML()
{
	qDebug()<<"UIDraftWorkspace::saveASXML : not implement yet";
	
}

void UIDraftWorkspace::generateCode()
{
	if(uiform == 0){
		QMessageBox::warning(0,
			QString(tr("Warning")),QString(tr("You must add a form first")));
	}
	else{
		if(uiCodeSnippet == 0)
		{
			uiCodeSnippet = new D3DUICodeSnippet(uiform->name());
			uiCodeSnippet->genCode(uiform,uiform->size());
		}
	}
}


void UIDraftWorkspace::addForm()
{
	if(uiform == 0)
	{
		uiform = new UIFormWidget(this,Qt::SubWindow | Qt::Window);
		uiform->setFrameStyle(QFrame::WinPanel | QFrame::Raised);

		setWidget(uiform);
		uiform->resize(600,400);
	}
	else
	{
		QMessageBox::warning(this,QString(tr("Warning")),
			QString(tr("The multiwindow mode is not implemented yet")) );
	}
}


//Slots
void UIDraftWorkspace::resizeUIForm(const QString& sizeString)
{
	qDebug()<<"UIDraftWorkspace::resizeWidget slot: @param: "<<sizeString;
	QString tuncate = ",";
	int index = sizeString.indexOf(tuncate);
	if(index == -1)
	{
		qDebug()<<"input error,";
		//TODO:Use the Logger displayer
	}
	QString heightString = sizeString.right(index);
	QString widthString = sizeString.left(index);
	int width = widthString.toInt();
	int height = heightString.toInt();
	qDebug()<<"parsed width: "<<width<<" height: "<<height;
	
	uiform->resize(width,height);
}


void UIDraftWorkspace::moveUIForm(const QString& moveString)
{
	qDebug()<<"UIDraftWorkspace::moveWidgetslot: @param: "<<moveString;
	QChar tuncate(',');
	int index = moveString.indexOf(tuncate);
/*	if(index = -1)
	{
		qDebug()<<"input error";
	}
*/
	QString posXString = moveString.left(index);
	QString posYString = moveString.right(index);
	int posX = posXString.toInt();
	int posY = posYString.toInt();
	qDebug()<<"parsed posX: "<<posX<<"parsed PosY: "<<posY;
	uiform->move(posX,posY);
}

void UIDraftWorkspace::changeUIFormName(const QString& name)
{
	uiform->setName(name);
}
