#include <QApplication>
#include "QViewpad.h"
#include <gtest/gtest.h>
#include "test.hpp"

int main(int argc,char ** argv)
{
  QApplication app(argc,argv);

  ::testing::InitGoogleTest(&argc,argv);
  RUN_ALL_TESTS();

  QViewpad * viewpad = new QViewpad();
  viewpad->show();

  return app.exec();
}
