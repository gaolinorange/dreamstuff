#ifndef DialogCodePreview_H
#define DialogCodePreview_H

#include "ui/ui_DialogCodePreview.hpp"
#include <QtGui>

class DialogCodePreview : public Ui_DialogCodePreview,public QDialog
{
public:
	DialogCodePreview(QDialog* parent = 0)
		: QDialog(parent)
	{
		setupUi(this);
	}
	~DialogCodePreview()
	{

	}
public:
	/**
	* fillTabWidgetContent:
	* search the filename in current directory by className
	* @param: className the form's name,also indicate the generated header& cpp file name
	*/
	void fillTabWidgetContent(const QString& className)
	{
		QString headerFilename = className+".hpp";
		QString cppFilename = className+".cpp";

		qDebug()<<"header name : "<<headerFilename;
		qDebug()<<"cpp file name: "<<cppFilename;

		QFile headerFile(headerFilename);
		QFile cppFile(cppFilename);

		if(!headerFile.open(QIODevice::ReadOnly | QIODevice::Text))
		{
			QLogger::getSingletonPtr()->appendMessage(QString(tr("The header file:  "))+headerFilename+QString(tr("  did not exists")));
			return;
		}

		QTextStream headerContentStream(&headerFile);
		QString line = headerContentStream.readLine();
		while(!line.isNull()){
			textEditHeader->append(line);		
			line = headerContentStream.readLine();		
		}

		//cpp file content
		if(!cppFile.open(QIODevice::ReadOnly))
		{
			QLogger::getSingletonPtr()->appendMessage(QString(tr("The cpp file: "))+cppFilename+QString(tr(" did not exists")));
			return;
		}

		QTextStream cppContentStream(&cppFile);
		line = cppContentStream.readLine();
		while(!line.isNull()){
			textEditSource->append(line);
			line = cppContentStream.readLine();
		}
	}
};
#endif