#ifndef MAINPANEL_H
#define MAINPANEL_H

#include <QWidget>
#include <QButtonGroup>
#include <QString>
#include <QHBoxLayout>
#include "mainpanelitem.h"
#include <QGroupBox>


class GMainPanel : public QWidget
{
public:
	GMainPanel(QWidget * parent) 
		: QWidget(parent)
	{
		buttonGroup = new QButtonGroup(parent);
		numItems = 9;
		QString str;

		layout = new QHBoxLayout();

		items = new MainPanelItem [numItems];
		for(int i = 0; i < numItems; i++)
		{
			str = str.setNum(i);
			items[i].setText(str);
			items[i].setCheckable(true);

			if(i == numItems/2)
				items[i].setChecked(true);

			buttonGroup->addButton(&items[i],i);
			layout->addWidget(&items[i]);
		}

		setLayout(layout);
	}
	~GMainPanel()
	{
		delete items;
		delete buttonGroup;
		delete layout;
	}
public:
	QButtonGroup * getButtonGroup() { return buttonGroup;}

	//for receiving results
	bool getValueString(QString& );
private:
	QHBoxLayout * layout;
	QButtonGroup * buttonGroup;
	MainPanelItem * items;
	int numItems;
};

#endif