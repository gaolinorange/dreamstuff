#include <QTest/QTest>
#include <gtest/gtest.h>
#include "../QViewpad.h"

class ViewpadTest : public ::testing::Test
{
 protected:
  virtual void SetUp()
    {
      viewpad = new QViewpad();
    }
  virtual void TearDown()
    {
      delete viewpad;
    }

  QViewpad * viewpad;
};

TEST_F(ViewpadTest,testInit)
{
}

TEST_F(ViewpadTest,testMouseClick)
{
  
}
