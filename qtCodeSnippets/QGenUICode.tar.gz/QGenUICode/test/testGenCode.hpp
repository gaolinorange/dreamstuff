#include <gtest/gtest.h>


TEST(GoogleTestTest,testGoogleTestIsOK)
{
  EXPECT_EQ(true,true);
}
