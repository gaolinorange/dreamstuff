#ifndef WIDGET_CONTAINER_H
#define WIDGET_CONTAINER_H

#include <QLabel>
#include <QPushButton>
#include "dragable_button.h"
#include <QVBoxLayout>
#include <QGroupBox>
#include <QButtonGroup>


class WidgetContainer : public QGroupBox
{
  Q_OBJECT
  public:
  WidgetContainer(const QString & title,QWidget * parent = 0)
    : QGroupBox(title,parent)
  {
	  labelBtn.setText("Label");
	labelBtn.setCheckable(true);
	labelBtn.setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
    buttonBtn.setText("Button");
	buttonBtn.setCheckable(true);
	buttonBtn.setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);

	menuBtn.setText("Menu");
	menuBtn.setCheckable(true);
	menuBtn.setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
	
    buttonGroup.addButton(&labelBtn);
    buttonGroup.addButton(&buttonBtn);
	buttonGroup.addButton(&menuBtn);

    QVBoxLayout * vbox = new QVBoxLayout;

    vbox->addWidget(&labelBtn);
    vbox->addWidget(&buttonBtn);
	vbox->addWidget(&menuBtn);
	vbox->addStretch();

	setLayout(vbox);
  }
  ~WidgetContainer()
  {}
  
public:

public:
  QButtonGroup buttonGroup;

  DragableButton labelBtn;
  DragableButton buttonBtn;
  DragableButton menuBtn;
};

#endif
