#include "SubPanel.h"
#include <QtDebug>


void GSubPanel::setIndexValue(int idx,const QString& value)
{
	if(idx >= 3)
	{
		qDebug()<<"error input, idx should smaller than 3 , actual : "<<idx;
		return;
	}
	items[idx].setValue(value.toInt());
}

GPanelItem* GSubPanel::getItem(int idx)
{
	if(idx >=3)
	{
		qDebug()<<"error input, idx should small than "<<numItems<<" actual : "<<idx;
		return NULL;
	}
	return &items[idx];
}
