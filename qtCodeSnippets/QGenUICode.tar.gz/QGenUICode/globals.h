#ifndef GLOBALS_H
#define GLOBALS_H

#include "main_widget.h"

extern MainWidget * gMainWidget;


#endif