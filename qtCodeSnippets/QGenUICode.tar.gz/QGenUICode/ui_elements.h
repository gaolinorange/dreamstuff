#ifndef UI_ELEMENTS_H
#define UI_ELEMENTS_H

#include <QWidget>
#include <QMimeData>
#include <QDrag>
#include <QtDebug>
#include <QPoint>
#include <QString>
#include <QMouseEvent>
#include <QByteArray>
#include <QDataStream>
#include "qlogger.h"


enum UIElementType
{
	UI_LABEL = 0,
	UI_BUTTON,
	UI_MENU,


	UI_MAX = 0x32
};

/**
The base class for any widgets that are dragable in
ui_form_widget
*/
class UIElement : public QWidget
{
public:
	UIElement(UIElementType elementType,QWidget* parent = 0)
		: QWidget(parent)
	{
		type_ = elementType;
	}
	~UIElement()
	{

	}
public:
	void setElementType(UIElementType type)
	{
		type_ = type;
	}
	UIElementType getElementType()
	{
		return type_;
	}
public slots:
	virtual void changeName(const QString& ) = 0;
	virtual void changePos(const QString& ) = 0;
	virtual void changeSize(const QString& ) = 0;
protected:
	/*
	void mousePressEvent(QMouseEvent* event)
	{
		qDebug()<<"UIElement::MousePreseEvent..";
		if(event->button() == Qt::LeftButton){
			dragStartPosition = event->pos();
		}
	}
	*/
	void mouseMoveEvent(QMouseEvent* event)
	{
		qDebug()<<"UIElement::MouseMoveEvent...";

		if(!(event->buttons() & Qt::LeftButton))
			return;
		if( (event->pos()-dragStartPosition).manhattanLength()
			< QApplication::startDragDistance())
			return;

		QDrag * drag = new QDrag(this);
		QMimeData* mimeData = new QMimeData;
		QByteArray byteArray;
		QDataStream dataStream(&byteArray,QIODevice::WriteOnly);
		dataStream<<(int)type_;
		dataStream<<event->pos();

		mimeData->setData("application/ui_element_movement",byteArray);
		drag->setMimeData(mimeData);

		qDebug()<<mimeData;

		Qt::DropAction dropAction = drag->exec(Qt::MoveAction);

		event->accept();
	}
	
protected:
	QPoint dragStartPosition;
	UIElementType type_;
};

class UIPushButton : public QPushButton,public UIElement
{
public:
	UIPushButton(const QString& title,QWidget* parent)
		: QPushButton(title,parent),UIElement(UI_BUTTON,parent)
	{	
	}
	~UIPushButton()
	{
	}
public slots:
	virtual void changeName(const QString& nameString)
	{
		setText(nameString);
	}
	virtual void changeSize(const QString& sizeString)
	{
		QLogger::getSingletonPtr()->appendMessage(QString("sizeString is: ")+sizeString);

	}
	virtual void changePos(const QString& posString)
	{

	}
protected:
	void mousePressEvent(QMouseEvent* event)
	{
		UIElement::mousePressEvent(event);
	}
	void mouseMoveEvent(QMouseEvent* event)
	{
		UIElement::mouseMoveEvent(event);
	}
};

class UILabel: public QLabel,public UIElement
{
public:
	UILabel(const QString& title,QWidget* parent)
		: QLabel(title,parent),UIElement(UI_LABEL,parent)
	{
	}
	~UILabel()
	{
	}	
public slots:
	virtual void changeName(const QString& nameString)
	{
		setText(nameString);
	}
	virtual void changePos(const QString& posString)
	{

	}
	virtual void changeSize(const QString& sizeString)
	{

	}

protected:
	void mousePressEvent(QMouseEvent* event)
	{
		UIElement::mousePressEvent(event);
	}
	void mouseMoveEvent(QMouseEvent* event)
	{
		UIElement::mouseMoveEvent(event);
	}
};

class UIMenu : public QMenu,public UIElement
{
public:
	UIMenu(const QString& title,QWidget * parent)
		: QMenu(title,parent),UIElement(UI_MENU,parent)
	{
	}
	~UIMenu()
	{

	}
protected:
	virtual void changeName(const QString& nameString)
	{

	}
	virtual void changePos(const QString& posString)
	{

	}
	virtual void changeSize(const QString& sizeString)
	{

	}
};

#endif