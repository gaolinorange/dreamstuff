#ifndef MAIN_WIDGET_H
#define MAIN_WIDGET_H

#include <QWidget>
#include "property_widget.h"
#include "widget_container.h"
#include "list_view.h"
#include "ui_draft_workspace.h"
#include <QScrollArea>

class QLogger;
class QMenuBar;
class QMenu;
class QAction;


class MainWidget : public QWidget
{
	Q_OBJECT
public:
  MainWidget(QWidget* parent = 0)   
	  : QWidget(parent)
  {
	  widgetContainer = 0;
	  propertyWidget = 0;
	  workspaceWidget = 0;
	  listViewWidget = 0;
	
	
	  createUI();//UI must be created before createMenu,because some action related to the widgets
	  createMenu();

	  setupConnections();
	  setLayout(&mainLayout);
  }
  ~MainWidget()
  {
	  if(widgetContainer)
		  delete widgetContainer;
	  widgetContainer = 0;
	  if(propertyWidget)
		  delete propertyWidget;
	  propertyWidget = 0;
	  if(workspaceWidget)
		  delete workspaceWidget;
	  workspaceWidget = 0;

	  if(listViewWidget)
		  delete listViewWidget;
	  listViewWidget = 0;
  }
public:

protected:
	
public slots:
  void buttonGroupSelectChanged(QAbstractButton* button);
  void helpAbout();
  void fileNew();
  void fileSaveAsXML();
  void fileGenCode();
  void fileClose();

  void viewPreviewCode();
  void viewToggleShowGrid();
private:
	void createMenu();
	void createUI();
	//set up the extra signal-slot connections
	void setupConnections();
public:
	WidgetContainer* getWidgetContainer() { return widgetContainer; }
	PropertyWidget * getPropertyWidget() { return propertyWidget; }
	ListViewWidget* getListViewWidget() { return listViewWidget; }
	UIDraftWorkspace* getUIDraftWorkSpace() { return workspaceWidget; }

private:
	QGridLayout mainLayout;

	WidgetContainer * widgetContainer;  
  PropertyWidget * propertyWidget;
  ListViewWidget * listViewWidget;
  UIDraftWorkspace* workspaceWidget;
  
private://menu related
	QMenuBar * menuBar;
	QMenu * fileMenu;
	QAction * newAction;
	QAction * saveXMLAction;
	QAction * genCodeAction;
	QAction* closeAction;
	QAction * exitAction;

	QMenu* viewMenu;
	QAction* previewCodeAction;
	QAction* showGridAction;
	
	QMenu * helpMenu;
	QAction * aboutAction;
};

#endif
