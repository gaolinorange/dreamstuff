#ifndef QVIEWPAD_H
#define QVIEWPAD_H

#include <QWidget>
#include "SubPanel.h"
#include "MainPanel.hpp"
#include "LinkPolygon.h"
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>


class QViewpad : public QWidget
{
	Q_OBJECT
public:
	QViewpad(QWidget * parent = 0)
		: QWidget(parent)
	{
		subPanel = new GSubPanel(this);
		mainPanel = new GMainPanel(this);
		linkPolygon = new LinkPolygon(this);

		resultLabel = new QLabel(QString(tr("The result will be display here")),this);
		okButton = new QPushButton(QString(tr("OK")),this);
		QObject::connect(okButton,SIGNAL(clicked()),this,SLOT(displayResult()));

		layout = new QGridLayout(this);
		layout->addWidget(mainPanel,0,0,1,3);
		layout->addWidget(linkPolygon,1,0,1,3);
		layout->addWidget(subPanel,2,0,1,1);
		layout->addWidget(resultLabel,3,0,1,2);
		layout->addWidget(okButton,3,1,1,1);

		setLayout(layout);

		setupConnection();
	}
	~QViewpad()
	{
		delete layout;
		delete subPanel;
		delete mainPanel;
		delete linkPolygon;
	}
private:
	void setupConnection();
	void _updateSubPanel(QAbstractButton * prevBtn,
		QAbstractButton * midBtn,QAbstractButton * afterBtn);
	
	void _updateLinkPolygon(QAbstractButton * prevBtn,
		QAbstractButton * midBtn,
		QAbstractButton* afterBtn);

private slots:
	void updateSubPanelAndPolygon(QAbstractButton* );
	void displayResult();
private:
	LinkPolygon * linkPolygon;
	GSubPanel * subPanel;
	GMainPanel * mainPanel;
	QGridLayout * layout;

	QLabel * resultLabel;
	QPushButton * okButton;
};

#endif
