/**
   LinkPolygon:
    for displaying the Polygon linking MainPanel and SubPanel
*/

#ifndef LINKPOLYGON_H
#define LINKPOLYGON_H

#include <QPoint>
#include <QPainter>
#include <QWidget>
#include <QtDebug>


/**
   QPolygon provide the logical points, and QPainter paint the visual points
 */

class LinkPolygon  : public QWidget
{
	Q_OBJECT
 public:
	 LinkPolygon(QWidget * parent = 0) : QWidget(parent)
    {
   	  numPoints = 4;
	  points = new QPoint [numPoints];
    }
  ~LinkPolygon()
    {
		if(points)
			delete points;
		points = 0;
    }
 public:
   void setPoint(int idx,const QPoint & p)
    {
      if(idx <= numPoints)
	  {
		  points[idx] = p;
	  }
    }

  void printPoints()
  {
	  for(int i = 0; i < numPoints;i++)
	  {
		  qDebug()<<points[i];
	  }
  }
protected slots:
	virtual void paintEvent(QPaintEvent * event)
	{
		qDebug()<<"LinkPolygon paintEvent";
		QPainter painter(this);
	
		painter.setBrush(QBrush(QColor(0,0,255),Qt::Dense1Pattern));
		painter.drawPolygon(points,numPoints);

	
//		testPaint();
	}
private:
	void testPaint()
	{
		qDebug()<<"LinkPolygon: testPaint..";
		static QPoint* testPoints = new QPoint[4];
		
		testPoints[0] = QPoint(10,10);
		testPoints[1] = QPoint(70,30);
		testPoints[2] = QPoint(80,60);
		testPoints[3] = QPoint(20,80);

		QPainter painter(this);
		painter.drawPolygon(testPoints,numPoints);
	}
 private:
	 int numPoints;
	 QPoint* points;	 
};


#endif
