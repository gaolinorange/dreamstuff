/**
   The draft workspace enable the drag and drop events,
   and can from it to generate a xml file for later usage
 */

#ifndef UI_DRAFT_WORKSPACE_H
#define UI_DRAFT_WORKSPACE_H

#include <QWidget>
#include <QScrollArea>
#include <QGroupBox>
#include "ui_form_widget.h"
#include <QBoxLayout>
#include "d3dui_code_snippet.h"


class UIDraftWorkspace : public QScrollArea
{
	Q_OBJECT
public:
	UIDraftWorkspace(QWidget * parent)
		: QScrollArea(parent)
  {
	   uiform = 0;
	   uiCodeSnippet = 0;
  }
  ~UIDraftWorkspace()
  {	 
	  if(uiform)
		  delete uiform;
	  uiform = 0;
	  if(uiCodeSnippet){
		 delete uiCodeSnippet;
		 uiCodeSnippet = 0;
	  }
  }

public slots:
	void resizeUIForm(const QString& sizeString);
	void moveUIForm(const QString& moveString);
	void changeUIFormName(const QString& nameString);

public:
	void addForm();
	void closeForm()
	{
		if(uiform)
			delete uiform;
		uiform = 0;
		if(uiCodeSnippet)
			delete uiCodeSnippet;
		uiCodeSnippet = 0;
	}
	UIFormWidget * form()
	{
		if(uiform == 0)
			return NULL;
		return uiform;
	}
public:	
  void saveAsXML();
  void generateCode();
 
private:
	UIFormWidget * uiform;
	D3DUICodeSnippet * uiCodeSnippet;
//	QWidget* currentActiveForm;//current there only one active form allowed,so this is not need now
};

#endif
