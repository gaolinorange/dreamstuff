#ifndef QLOGGER_H
#define QLOGGER_H

#include <QListWidget>
#include <QtDebug>

class QLogger : public QListWidget
{
public:
  static QLogger* getSingletonPtr()
  {
    Q_ASSERT(logger != NULL);

    return logger;
  }
public:
  void appendMessage(const QString& message)
  {
	  addItem(message);
	  update();
  }
public:
  QLogger(QWidget * parent)
    : QListWidget(parent)
  {    
	  setSizePolicy(QSizePolicy::Minimum,QSizePolicy::Minimum);
  }
  ~QLogger()
  {
  }
public:
  static QLogger* logger;
};



#endif
