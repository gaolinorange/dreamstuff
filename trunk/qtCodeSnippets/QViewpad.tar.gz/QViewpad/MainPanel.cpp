#include "MainPanel.hpp"
#include <QString>

bool GMainPanel::getValueString(QString & resultString)
{
	for(int i = 0; i < numItems; i++)
	{
		resultString += items[i].text();
	}

	return true;
}


