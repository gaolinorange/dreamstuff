#include "globals.h"

MainWidget* gMainWidget = 0;