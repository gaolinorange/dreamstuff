/****************************************************************************
** Meta object code from reading C++ file 'PanelItem.h'
**
** Created: Tue Nov 10 11:28:47 2009
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "PanelItem.hpp"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'PanelItem.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_GPanelItem[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x08,
      26,   11,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_GPanelItem[] = {
    "GPanelItem\0\0increaseNum()\0decreaseNum()\0"
};

const QMetaObject GPanelItem::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_GPanelItem,
      qt_meta_data_GPanelItem, 0 }
};

const QMetaObject *GPanelItem::metaObject() const
{
    return &staticMetaObject;
}

void *GPanelItem::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_GPanelItem))
        return static_cast<void*>(const_cast< GPanelItem*>(this));
    return QWidget::qt_metacast(_clname);
}

int GPanelItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: increaseNum(); break;
        case 1: decreaseNum(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
