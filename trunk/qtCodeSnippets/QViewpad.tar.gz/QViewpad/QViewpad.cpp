#include "QViewpad.h"

#include <QList>
#include <QAbstractButton>
#include <QButtonGroup>
#include <QPoint>
#include <QtDebug>

//slots
void QViewpad::updateSubPanelAndPolygon(QAbstractButton* button)
{
	//Update SubPanel: todo: fetch the neighbor numbers and redisplay it .
	QAbstractButton* selectedBtn = NULL;
	int id;
	QAbstractButton* prevBtn = NULL;
	QAbstractButton* afterBtn = NULL;
	QButtonGroup * buttonGroup = mainPanel->getButtonGroup();
	
	foreach(selectedBtn,buttonGroup->buttons())
	{
		if(selectedBtn == button)
		{
			id = buttonGroup->id(selectedBtn);
			//judge
			prevBtn = buttonGroup->button(id-1);
			afterBtn = buttonGroup->button(id+1);
			_updateSubPanel(prevBtn,selectedBtn,afterBtn);
			_updateLinkPolygon(prevBtn,selectedBtn,afterBtn);
		}
	}
}

void QViewpad::_updateLinkPolygon(QAbstractButton * prevBtn,
								  QAbstractButton * midBtn,
								  QAbstractButton* afterBtn)
{
	if(prevBtn == 0)
	{

	}
	else if(afterBtn == 0)
	{

	}
	else
	{
		linkPolygon->setPoint(0,QPoint(prevBtn->x(),prevBtn->y()+prevBtn->height()));
		linkPolygon->setPoint(1,QPoint(afterBtn->x()+afterBtn->width(),afterBtn->y()+prevBtn->height() ));
		linkPolygon->setPoint(2,QPoint(subPanel->x()+subPanel->width(),subPanel->y()));
		linkPolygon->setPoint(3,QPoint(subPanel->x(),subPanel->y()));
		emit linkPolygon->update(); //trigger the slots : paintEvent 
	}
	linkPolygon->printPoints();
}

void QViewpad::_updateSubPanel(QAbstractButton * prevBtn,
							  QAbstractButton * midBtn,
							  QAbstractButton* afterBtn)
{
	//first,update the panelItems
	if(prevBtn == 0)
	{
		qDebug()<<"Warning: prevBtn is 0";
		subPanel->setIndexValue(1,midBtn->text());
		subPanel->setIndexValue(2,afterBtn->text());
		subPanel->setIndexValue(0,QString("0"));
	}
	else if(afterBtn == 0)
	{
		qDebug()<<"Warning: afterBtn is 0";
		subPanel->setIndexValue(0,prevBtn->text());
		subPanel->setIndexValue(1,midBtn->text());
		subPanel->setIndexValue(2,QString("0"));
	}
	else
	{
		subPanel->setIndexValue(0,prevBtn->text());
		subPanel->setIndexValue(1,midBtn->text());
		subPanel->setIndexValue(2,afterBtn->text());
	}
}

void QViewpad::setupConnection()
{
	QButtonGroup * buttonGroup = mainPanel->getButtonGroup();
	
	QObject::connect(buttonGroup,SIGNAL(buttonClicked(QAbstractButton*)),this,SLOT(updateSubPanelAndPolygon(QAbstractButton*)));
}



void QViewpad::displayResult()
{
	QString str;
	mainPanel->getValueString(str);
	qDebug()<<str;

	resultLabel->setText(str);
}