/**
to implement the dragable widget
*/

#ifndef DRAGABLE_BUTTON_H
#define DRAGABLE_BUTTON_H

#include <QPushButton>
#include <QDrag>
#include <QMimeData>
#include <QtDebug>
#include <QMouseEvent>
#include <QPoint>
#include <QApplication>

/**
DragableButton is use to transfer the data between
widget_container and ui_form
*/
class DragableButton : public QPushButton
{
public:
  DragableButton(QWidget * parent = 0){}
  DragableButton(const QString& text,QWidget * parent = 0)
    : QPushButton(text,parent)
  {
  }
  ~DragableButton()
  {
  }
protected:
	void mousePressEvent(QMouseEvent* event)
	{
		if(event->button() == Qt::LeftButton)
		{
			dragStartPosition = event->pos();
		}
	}
	void mouseMoveEvent(QMouseEvent * event)
	{
		if(!(event->buttons() & Qt::LeftButton))
			return;
		qDebug()<<"QApplication::startDragDistance()="<<QApplication::startDragDistance();
		if( (event->pos()-dragStartPosition).manhattanLength()
			< QApplication::startDragDistance() )
			return;

		QDrag * drag = new QDrag(this);
		QMimeData* mimeData = new QMimeData;

		mimeData->setText(text());
		drag->setMimeData(mimeData);

		Qt::DropAction dropAction = drag->exec(Qt::CopyAction | Qt::MoveAction);
		qDebug()<<"the dropAction is: "<<dropAction;

		event->accept();
	}

private:
	QPoint dragStartPosition;
};


#endif
