#include "main_window.h"
#include <QMenuBar>
#include <QMenu>
#include <QAction>


void MainWindow::setupMenu()
{
	menuBar = new QMenuBar;
	fileMenu = new QMenu(QString("&File"),this);
	newAction = new QAction(QString(tr("&New")),this);
	fileMenu->addAction(newAction);
	QObject::connect(newAction,SIGNAL(triggered()),this,SLOT(fileNew()));

	saveXMLAction = new QAction(QString(tr("&Save As XML")),this);
	fileMenu->addAction(saveXMLAction);
	QObject::connect(saveXMLAction,SIGNAL(triggered()),this,SLOT(fileSaveAsXML()));

	genCodeAction = new QAction(QString(tr("&Gen Code")),this);
	fileMenu->addAction(genCodeAction);
	QObject::connect(genCodeAction,SIGNAL(triggered()),this,SLOT(fileGenCode()));

	exitAction = new QAction(QString(tr("E&xit")),fileMenu);
	fileMenu->addAction(exitAction);
	QObject::connect(exitAction,SIGNAL(triggered()),qApp,SLOT(quit()));
	menuBar->addMenu(fileMenu);

	viewMenu = new QMenu(QString(tr("&View")));
	previewCodeAction = new QAction(QString(tr("Preview Code")),viewMenu);
	viewMenu->addAction(previewCodeAction);
	QObject::connect(previewCodeAction,SIGNAL(triggered()),this,SLOT(viewPreviewCode()));
	showGridAction = new QAction(QString(tr("Show Grid")),viewMenu);
	viewMenu->addAction(showGridAction);
	QObject::connect(showGridAction,SIGNAL(triggered()),this,SLOT(viewToggleShowGrid()));
	menuBar->addMenu(viewMenu);

	helpMenu = new QMenu(QString(tr("&Help")));
	aboutAction = new QAction(QString(tr("&About")),helpMenu);
	helpMenu->addAction(aboutAction);
	QObject::connect(aboutAction,SIGNAL(triggered()),this,SLOT(helpAbout()));
	menuBar->addMenu(helpMenu);

	setMenuBar(menuBar);
}

void MainWindow::setupCentralWidget()
{
	mainWidget = new MainWidget(this);
}




