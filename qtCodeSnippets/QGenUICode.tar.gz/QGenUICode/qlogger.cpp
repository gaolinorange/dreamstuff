#include "qlogger.h"

QLogger* QLogger::logger = NULL;